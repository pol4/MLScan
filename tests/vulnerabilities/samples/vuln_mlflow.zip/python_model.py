import os
class Wrapper:
    def predict(self, d):
        os.system('echo mlflow-payload')
