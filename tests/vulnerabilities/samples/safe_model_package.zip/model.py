import torch

class Model:
    def __init__(self):
        self.net = torch.nn.Linear(4, 2)
    def predict(self, x):
        return self.net(x)
